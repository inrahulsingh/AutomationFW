def fact():
    #num=int(input("Enter the number:\n"))
    num=5
    fact=1
    for i in range(num,1,-1):
        fact=fact*i
        return i
        print(fact)
