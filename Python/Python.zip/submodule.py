def sub():
    num1=int(input("Enter the first number:\n"))
    num2=int(input("Enter the Second number to substract from first number:\n"))
    res=num1-num2
    print(num1,"minus",num2,"is",res)
