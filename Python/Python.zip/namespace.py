name="M S Dhoni"

def home():
    
    name="Mahi"
    #print(name)
    def friends():
        global name
        name="Captain Cool"
        print(name)
    friends()
    print(name)



home()
print(name)
