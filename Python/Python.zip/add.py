def add():
    num1=int(input("Enter the first number:\n"))
    num2=int(input("Enter the Second number:\n"))
    res=num1+num2
    print("The sum of",num1,"and",num2,"is",res)
