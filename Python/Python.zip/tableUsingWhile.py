num=int(input("Enter a number:\n"))
limit=int(input("Enter a limit number:\n"))
i=1
while (i<=limit):
    res=num*i
    print(num, "*",i, "=", res)
    i+=1
