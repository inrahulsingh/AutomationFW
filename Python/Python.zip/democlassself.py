class democlass():
    def demo_method(self):
        print("Demo Method Executed")
