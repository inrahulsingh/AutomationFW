class point():
    num1=10
    num2=20
