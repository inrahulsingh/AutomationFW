read_data=open('C:\\test2pic.JPG','rb')
print(read_data.read())
