n=int(input("Enter the number\n"))
res=1
for i in range(1,11,1):
    res=n*i
    print(n,"*",i,"=",res)
