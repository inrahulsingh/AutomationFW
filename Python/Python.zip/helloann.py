def hello(fname:str,lname:str):
    print("hello",fname,lname)
    
