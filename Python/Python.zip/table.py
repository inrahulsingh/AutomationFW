num=int(input("Enter a number:\n"))
for i in range(1,11,1):
        value=num*i
        print("%d * %d = %d"%(num,i,value))
