def mul():
    num1=int(input("Enter the first number:\n"))
    num2=int(input("Enter the Second number:\n"))
    res=num1*num2
    print(num1,"multiplied by",num2,"is",res)
