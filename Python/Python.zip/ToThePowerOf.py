num=int(input("Enter a number:\n"))
power=int(input("Enter to the power value:\n"))
i=1
while (i<=power):
    res=num**i
    print(res)
    i+=1
