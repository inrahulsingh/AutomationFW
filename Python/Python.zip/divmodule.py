def div():
    num1=int(input("Enter the dividend\n"))
    num2=int(input("Enter the divisor\n"))
    res=num1/num2
    print(num1,"divided by",num2,"is",res)
